<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }
$manifest = array();
$manifest['title'] = esc_html__( 'VideoPro - Cooking', 'videopro' );
$manifest['screenshot'] = 'http://videopro.cactusthemes.com/data/videopro-cooking.jpg';
$manifest['preview_link'] = 'http://videopro.cactusthemes.com/cooking';
$manifest['demo_link'] = 'http://videopro.cactusthemes.com/data/videopro-cooking-sample-data.zip';