<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }
$manifest = array();
$manifest['title'] = esc_html__( 'VideoPro - Poster', 'videopro' );
$manifest['screenshot'] = 'http://videopro.cactusthemes.com/data/videopro-poster.jpg';
$manifest['preview_link'] = 'http://videopro.cactusthemes.com/poster';
$manifest['demo_link'] = 'http://videopro.cactusthemes.com/data/videopro-poster-sample-data.zip';