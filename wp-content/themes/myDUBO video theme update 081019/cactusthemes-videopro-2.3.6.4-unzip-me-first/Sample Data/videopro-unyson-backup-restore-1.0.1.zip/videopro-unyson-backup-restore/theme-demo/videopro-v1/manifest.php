<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }
$manifest = array();
$manifest['title'] = esc_html__( 'VideoPro - Demo 1 (General)', 'videopro' );
$manifest['screenshot'] = 'http://videopro.cactusthemes.com/data/videopro-v1.jpg';
$manifest['preview_link'] = 'http://videopro.cactusthemes.com/v1';
$manifest['demo_link'] = 'http://videopro.cactusthemes.com/data/videopro-v1-sample-data.zip';