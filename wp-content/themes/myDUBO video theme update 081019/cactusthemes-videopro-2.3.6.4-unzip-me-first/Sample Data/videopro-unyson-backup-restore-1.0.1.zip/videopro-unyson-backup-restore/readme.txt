=== Cactus Unyson backup & demo content install extension ===
Contributors: Allen Walker
Tags: contact, form, contact form, feedback, email, ajax, captcha, akismet, multilingual

== How to use ==

First : Build content for your website >> navigate to Dashboard >> backup >> Create content backup

Then : Click to : "Create Demo"  ( the System will create a Demo in dashboard >> Tools >> Demo Content install, you can navigate to that menu to check ).

After "Create Demo" : A link will appear "Download Demo", click to download the demo content zip file, Unzip the download to a new folder with the name of the demo you want to create and change info in file manifest.php ( include Demo name, Demo preview img, Demo preview Link ).

Before Zip the package : Put the demo folder in <plugin>/theme-demo/< your theme text domain >/ , and also delete all the data in side the <plugin>/backups


*Note : for developer to integrate it to the theme, read the note.txt file

== Installation ==

1. Upload the entire `videopro-backup-extension` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

You will find 'Backup' menu in your WordPress admin panel >> Tools.
You will find 'Demo content install' menu in your WordPress admin panel >> Tools when there is demo conten avaiable.